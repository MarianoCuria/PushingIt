/// <reference types="cypress" />
import { ShoppingCartPage } from "../support/pages/shoppingCartPage";
import { HomePage } from "../support/pages/homePage";
import { LoginPage } from "../support/pages/loginPage";
import { ProductsPage } from "../support/pages/productsPage"
import { RegisterPage } from "../support/pages/registerPage";



describe('Page Object Model', () => { 
    let loginDatos;
    let productosCarrito;
    const registerPage = new RegisterPage();
    const loginPage = new LoginPage();
    const homePage = new HomePage();
    const productsPage = new ProductsPage();
    const shoppingCartPage = new ShoppingCartPage();

    before("Before", () => {
        cy.fixture('loginData').then(datos => {
          loginDatos = datos;
        })

        cy.fixture('products').then ( producto => {
          productosCarrito = producto;
        })
    });

  it('Pre Entrega', () => {
    cy.visit("");
    registerPage.registrarse();
    loginPage.escribirUsuario(loginDatos.username)
    loginPage.escribirContraseña(loginDatos.password)
    loginPage.clickBotonLogin();
    homePage.clickOnlineShop();
    productsPage.agregarProductos(productosCarrito.remeraNegra.producto);
    productsPage.cerrarVentanaEmergente();
    productsPage.agregarProductos(productosCarrito.gorraRoja.producto);
    productsPage.cerrarVentanaEmergente();
    productsPage.irAlCarrito();
    shoppingCartPage.verificarProductos(productosCarrito.remeraNegra.producto).should("have.text", productosCarrito.remeraNegra.producto)
    shoppingCartPage.verificarProductos(productosCarrito.gorraRoja.producto).should("have.text", productosCarrito.gorraRoja.producto)
    shoppingCartPage.verificarPrecioProducto(productosCarrito.remeraNegra.producto).should("have.text", ("$" + productosCarrito.remeraNegra.precio))
    shoppingCartPage.verificarPrecioProducto(productosCarrito.gorraRoja.producto).should("have.text", ("$" + productosCarrito.gorraRoja.precio))
    shoppingCartPage.mirarPrecioTotal();
    shoppingCartPage.verificarSumaPrecio().should("have.text", (productosCarrito.remeraNegra.precio + productosCarrito.gorraRoja.precio))

  });  

})