export class HomePage {

    clickOnlineShop () {
        cy.get('#onlineshoplink').click();
    }

}