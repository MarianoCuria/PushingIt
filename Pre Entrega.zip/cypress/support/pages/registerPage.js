export class RegisterPage {

    registrarse () {
    cy.get('#registertoggle').dblclick();
    }
}