export class LoginPage {

    escribirUsuario(username) {
        cy.get("#user").type(username);
    }

    escribirContraseña(password){
        cy.get("#pass").type(password);
    }

    clickBotonLogin(){
        cy.get("#submitForm").click()
    };


};
